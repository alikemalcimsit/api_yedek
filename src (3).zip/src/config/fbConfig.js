export const FACEBOOK_CONFIG = {
  VERIFY_TOKEN: 'ozel_token_facebook_webhook_2024',
  WEBHOOK_URL: 'https://medicine.crmpanel.tr/backend/wpwebhook.php', 
   TIMEOUT: 30000 // 30 saniye timeout - webhook yanıt vermezse istek iptal olur
};