import { BaseService } from '../base/base.service.js';

export class QuickMessagesService extends BaseService {
  constructor({ quickMessagesRepository }) {
    super(quickMessagesRepository);
  }


  
 
    // İsteğe bağlı ek sorgular buraya yazılabilir

  // Ek servis metodları buraya eklenebilir
}
