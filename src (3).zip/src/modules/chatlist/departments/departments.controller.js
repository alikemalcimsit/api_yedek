import { BaseController } from '../base/base.controller.js';

export class DepartmentsController extends BaseController {
  constructor({ departmentsService }) {
    super(departmentsService);
  }



  // Ek controller işlemleri burada override edilebilir
}
