import { BaseService } from '../base/base.service.js';

export class DepartmentsService extends BaseService {
  constructor({ departmentsRepository }) {
    super(departmentsRepository);
  }

    // İsteğe bağlı ek sorgular buraya yazılabilir

  // Ek servis metodları buraya eklenebilir
}
