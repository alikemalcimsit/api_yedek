import { BaseController } from '../base/base.controller.js';

export class OpportunitiesController extends BaseController {
  constructor({ opportunitiesService }) {
    super(opportunitiesService);
  }

 
}