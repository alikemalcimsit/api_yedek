import { BaseRepository } from "../base/base.repository.js";
export class TranslateRepository extends BaseRepository {
    constructor() { super(); }
    // DB yok; istersen ileride log / quota vs buraya ekleriz.
}
