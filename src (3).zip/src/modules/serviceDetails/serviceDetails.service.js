import { BaseService } from '../base/base.service.js';

export class ServiceDetailsService extends BaseService {
  constructor({ serviceDetailsRepository }) {
    super(serviceDetailsRepository);
  }

    // İsteğe bağlı ek sorgular buraya yazılabilir

  // Ek servis metodları buraya eklenebilir
}
