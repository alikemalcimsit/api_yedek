import { BaseController } from '../base/base.controller.js';

export class ServiceDetailsController extends BaseController {
  constructor({ serviceDetailsService }) {
    super(serviceDetailsService);
  }



  // Ek controller işlemleri burada override edilebilir
}
