import { BaseController } from '../base/base.controller.js';

export class ChatListController extends BaseController {
  constructor({ chatListService }) {
    super(chatListService);
  }



  // Ek controller işlemleri burada override edilebilir
}
